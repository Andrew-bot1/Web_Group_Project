<?php

function clean($key, $type = 'string', $src = INPUT_POST){
    
    $filter = FILTER_SANITIZE_SPECIAL_CHARS;
    $options = 0;
    if ($type === 'string'){
        $filter = FILTER_SANITIZE_STRING;
    }
    if ($type === 'email'){
        $filter = FILTER_SANITIZE_EMAIL;
    } elseif ($type === 'url'){
        $filter = FILTER_SANITIZE_URL;
    }elseif ($type === 'int'){
        $filter = FILTER_SANITIZE_NUMBER_INT;
    } elseif ($type === 'float'){
        $filter = FILTER_SANITIZE_NUMBER_FLOAT;
        $options = FILTER_FLAG_ALLOW_FRACTION;
    }

    $value = filter_input($src, $key, $filter, $options);

    return trim($value ?? '');
}

function esc($val){
    return htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
}

$username = $password = "";
$errors = [];
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = clean('name');
    $password = clean('password');
}
    if (empty($username)) {
        $errors[] = "Username is required.";
    }

    if (empty($password)){
        $errors[] = "Password is required.";
    } elseif (!preg_match("/(?=.*\d).{6,}/", $password)){
        $errors[] = "Password must be at least 6 characters and include a number.";
    }

    if (empty($errors)){

        $success = "Registration Successful! Username: " . esc($username);

        $name = $email = $password = "";
    }
?>


<!DOCTYPE html>
<!-- //I think this part should go in the HTML? 
    // THe prior code could either be linked in an upper portion of the html or 
    //put lower. -->

    <form action="" method="post">
        Username: <input type="text" name="Username" value="<?php echo esc($username); ?>" required><br><br>
        Password: <input type="password" name="Password"
                pattern="(?=.*\d).{6,}"
                title="Minimum 6 characters and at least one number" required><br><br>
        <input type="submit" value="Sign Up">
    </form>
</html>