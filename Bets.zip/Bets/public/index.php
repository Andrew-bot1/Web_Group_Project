<?php
require_once __DIR__ . '/../config/config.php';

// Get page from URL:  index.php?page=home
$page = $_GET['page'] ?? 'home';

// Map page keys → actual PHP files
$routes = [
    'home'       => BASE_PATH . '/src/home.php',
    'about'      => BASE_PATH . '/src/about.php',
    'items'      => BASE_PATH . '/src/Item_CRUD.php',
    'orders'     => BASE_PATH . '/src/Order_CRUD.php'
];

// If route exists, load it. Otherwise show 404.
if (array_key_exists($page, $routes)) {
    require_once $routes[$page];
} else {
    http_response_code(404);
    echo "<h1>404 - Page Not Found</h1>";
}
