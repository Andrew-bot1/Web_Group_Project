    <footer>
        <hr>
        <p>&copy; <?php echo date('Y'); ?> Store. All rights reserved.</p>
    </footer>
</body>
</html>