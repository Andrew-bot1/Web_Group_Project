 <footer>
    <p>&copy; 2025 Betsy</p>
  </footer>
</body>
</html>