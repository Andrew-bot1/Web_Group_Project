<?php
// Header include: render page top banner (logo + title + login) and navigation
// This header is the same on all pages - static branding and login link only

// Check if the session is not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$is_logged_in = isset($_SESSION['user_id']);
?>

<header>
  <img src="../public/assets/images/logo.png" alt="Betsy Logo" class="logo">
  <h1>Betsy</h1>
  <div class="header-login">
    <?php if ($is_logged_in): ?>
      <form method="post" action="./logout.php" style="display: inline;">
        <button type="submit" style="background:#e74c3c; class="btn btn-logout">Sign Out</button>
      </form>
    <?php else: ?>
      <a href="./account.php" class="btn">Login</a>
    <?php endif; ?>
  </div>
</header>

<?php
$NAV_HTML = <<<HTML
<nav>
  <ul>
    <li><a href="./index.php">Home</a></li>
    <li><a href="./account.php">Account</a></li>
    <li><a href="./contact.php">Contact</a></li>
  </ul>
</nav>
HTML;
?>