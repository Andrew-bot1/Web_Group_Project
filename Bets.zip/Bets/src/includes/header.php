<nav>
        <ul>
            <li><a href="<?php BASE_URL; ?>index.php">Home</a></li>
            <li><a href="<?php BASE_URL; ?>account.php">Account</a></li>
            <li><a href="<?php BASE_URL; ?>contact.php">Contact</a></li>
        </ul>
</nav>