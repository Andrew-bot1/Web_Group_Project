<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) : 'Store'; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/styles.css">
</head>
<body>
    <header>
        <h1>Store</h1>
        
    </header>
    <nav>
        <ul>
            <li><a href="<?php BASE_URL; ?>index.php?page=home">Home</a></li>
            <li><a href="<?php BASE_URL; ?>/index.php?page=about">About</a></li>
            <li><a href="<?php BASE_URL; ?>/index.php?page=Item_CRUD">Manage Items</a></li>
            <li><a href="<?php BASE_URL; ?>/index.php?page=Order_CRUD">Manage Orders</a></li>
        </ul>
    </nav>