<?php
// Header include: render page top banner (logo + title + login) and navigation
// This header is the same on all pages - static branding and login link only
?>

<header>
  <img src="../public/assets/images/logo.png" alt="Betsy Logo" class="logo">
  <h1>Betsy</h1>
  <div class="header-login">
    <a href="./account.php" class="btn">Login</a>
  </div>
</header>

<?php
$NAV_HTML = <<<HTML
<nav>
  <ul>
    <li><a href="./index.php">Home</a></li>
    <li><a href="./account.php">Account</a></li>
    <li><a href="./contact.php">Contact</a></li>
  </ul>
</nav>
HTML;
?>
