<?php require_once __DIR__.'/../config/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Betsy</title>
  <link rel="stylesheet" href="../public/assets/css/styles.css">
</head>
<body>
  <header>

    <img src="../public/assets/images/logo.png" alt="Betsy Logo" class="logo">

    <h1>Betsy</h1>
  </header>

  
<div class="layout">
  <?php require_once BASE_PATH.'/src/includes/header.php';?>
  <main>

      <h2>Contact Us</h2>
      <p>Email: info@productsystem.com</p>
      <p>Phone: (555) 123-4567</p>
      <p>Address: 123 Main Street, Example City, EX 12345</p>
    
  </main>

</div>

</body>
</html>
  <?php
  require_once BASE_PATH.'/src/includes/footer.php';
?>