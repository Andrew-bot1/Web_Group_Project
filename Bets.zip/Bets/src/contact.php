<?php 
require_once __DIR__.'/../config/config.php';
session_start();

$success_msg = '';
$error_msg = '';

// Handle contact form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_form'])) {
    $name = htmlspecialchars(trim($_POST['name'] ?? ''));
    $email = htmlspecialchars(trim($_POST['email'] ?? ''));
    $subject = htmlspecialchars(trim($_POST['subject'] ?? ''));
    $message = htmlspecialchars(trim($_POST['message'] ?? ''));

    if ($name && $email && $subject && $message) {
        // In production, send email here. For now, just show success.
        $success_msg = "Thank you for your message! We'll get back to you soon.";
    } else {
        $error_msg = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Betsy</title>
  <link rel="stylesheet" href="../public/assets/css/styles.css">
  <style>
    .contact-container {
      flex: 1;
      width: 90%;
      max-width: 1200px;
      margin: 2rem auto;
      padding: 2rem;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }

    .contact-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 3rem;
    }

    .contact-info h3 {
      color: #2c3e50;
      font-size: 1.5rem;
      margin-bottom: 1.5rem;
      border-bottom: 3px solid #3498db;
      padding-bottom: 0.5rem;
    }

    .info-item {
      margin-bottom: 2rem;
      padding: 1rem;
      background: #f9f9f9;
      border-left: 4px solid #3498db;
      border-radius: 4px;
    }

    .info-item strong {
      display: block;
      color: #2c3e50;
      font-size: 1rem;
      margin-bottom: 0.3rem;
    }

    .info-item p {
      margin: 0;
      color: #555;
      font-size: 0.95rem;
    }

    .contact-form h3 {
      color: #2c3e50;
      font-size: 1.5rem;
      margin-bottom: 1.5rem;
      border-bottom: 3px solid #3498db;
      padding-bottom: 0.5rem;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      color: #2c3e50;
      font-weight: 600;
    }

    .form-group input,
    .form-group textarea {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-family: Arial, sans-serif;
      font-size: 1rem;
      box-sizing: border-box;
      transition: border 0.3s ease;
    }

    .form-group input:focus,
    .form-group textarea:focus {
      outline: none;
      border: 2px solid #3498db;
      box-shadow: 0 0 8px rgba(52, 152, 219, 0.2);
    }

    .form-group textarea {
      resize: vertical;
      min-height: 140px;
    }

    .form-submit {
      background: #3498db;
      color: #fff;
      padding: 0.85rem 2rem;
      border: none;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s ease;
    }

    .form-submit:hover {
      background: #2980b9;
    }

    .message {
      padding: 1rem;
      border-radius: 6px;
      margin-bottom: 1.5rem;
    }

    .message.success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .message.error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    @media (max-width: 768px) {
      .contact-content {
        grid-template-columns: 1fr;
        gap: 2rem;
      }

      .contact-container {
        padding: 1rem;
      }
    }
  </style>
  <script>
    window.BASE_URL = '<?= BASE_URL ?>';
    window.ASSETS_PATH = (window.BASE_URL ? window.BASE_URL : '') + '/assets';
  </script>
</head>
<body>
  <?php require_once BASE_PATH.'/src/includes/header.php';?>

  <div class="layout">
    <?php if (isset($NAV_HTML)) echo $NAV_HTML; ?>
    <main>
      <div class="contact-container">
        <h1 style="text-align: center; color: #2c3e50; margin-bottom: 0.5rem;">Get in Touch</h1>
        <p style="text-align: center; color: #666; margin-bottom: 2rem;">We'd love to hear from you. Send us a message and we'll respond as soon as possible.</p>

        <?php if ($success_msg): ?>
          <div class="message success"><?= $success_msg ?></div>
        <?php endif; ?>

        <?php if ($error_msg): ?>
          <div class="message error"><?= $error_msg ?></div>
        <?php endif; ?>

        <div class="contact-content">
          <!-- Contact Information -->
          <div class="contact-info">
            <h3>📍 Contact Information</h3>
            
            <div class="info-item">
              <strong>Email</strong>
              <p><a href="mailto:info@betsy.com" style="color: #3498db; text-decoration: none;">info@betsy.com</a></p>
            </div>

            <div class="info-item">
              <strong>Phone</strong>
              <p><a href="tel:+15551234567" style="color: #3498db; text-decoration: none;">(555) 123-4567</a></p>
            </div>

            <div class="info-item">
              <strong>Address</strong>
              <p>123 Main Street<br>Example City, EX 12345<br>United States</p>
            </div>

            <div class="info-item">
              <strong>Business Hours</strong>
              <p>Monday - Friday: 9:00 AM - 6:00 PM<br>
              Saturday: 10:00 AM - 4:00 PM<br>
              Sunday: Closed</p>
            </div>
          </div>

          <!-- Contact Form -->
          <div class="contact-form">
            <h3>📧 Send us a Message</h3>
            
            <form method="post" action="">
              <input type="hidden" name="contact_form" value="1">

              <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" required>
              </div>

              <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required>
              </div>

              <div class="form-group">
                <label for="subject">Subject</label>
                <input type="text" id="subject" name="subject" required>
              </div>

              <div class="form-group">
                <label for="message">Message</label>
                <textarea id="message" name="message" required></textarea>
              </div>

              <button type="submit" class="form-submit">Send Message</button>
            </form>
          </div>
        </div>
      </div>
    </main>
  </div>

  <?php require_once BASE_PATH.'/src/includes/footer.php';?>
</body>
</html>