<?php
require_once __DIR__.'/../config/config.php';

require_once BASE_PATH.'/src/includes/helper.php';

// ----------------------------
// Database connection settings
// ----------------------------
$host = 'localhost';
$db   = 'betsy_db';
$user = 'root';
$pass = '';

session_start();

// ----------------------------
// CONNECT TO DATABASE
// ----------------------------
try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// ----------------------------
// Helper function to clean POST data
// ----------------------------
function get_post_data($key, $type = 'string') {
    if (!isset($_POST[$key])) return null;
    $value = trim($_POST[$key]);

    if ($type === 'int') return (int) filter_var($value, FILTER_SANITIZE_NUMBER_INT);
    if ($type === 'float') return (float) filter_var(str_replace(',', '.', $value), FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

// ----------------------------
// Handle POST forms
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_type = $_POST['form_type'] ?? '';

    // --- SIGN UP ---
    if ($form_type === 'signup') {
        $fname = clean('fname') ?? '';
        $lname = clean('lname') ?? '';
        $email = clean('email') ?? '';
        $password = $_POST['password'] ?? '';   // DO NOT sanitize password

        if (!$fname || !$lname || !$email || !$password) {
            $_SESSION['error_message'] = "All fields are required for sign up.";
        } else {
            // Hash the password before storing
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO user_table (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$fname, $lname, $email, $hashed_password]);
            $_SESSION['success_message'] = "Sign up successful! You can now log in.";
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;

    // --- LOGIN ---
    } elseif ($form_type === 'login') {
        $email = clean('email') ?? '';
        $password = $_POST['password'] ?? '';   // DO NOT sanitize password

        if (!$email || !$password) {
            $_SESSION['error_message'] = "Email and password are required.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM user_table WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Main verification line - use password_verify
            if ($user && password_verify($password, $user['password'])) {
                session_regenerate_id(true);  // Secure against session hijacking
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['success_message'] = "Login successful!";
            } else {
                $_SESSION['error_message'] = "Invalid email or password.";
            }
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;

    // --- ADD ITEM ---
    } elseif ($form_type === 'add_item' && isset($_SESSION['user_id'])) {
        $item_name = get_post_data('item_name');
        $item_desc = get_post_data('item_desc');
        $item_price = get_post_data('item_price', 'float');
        $item_qty = get_post_data('item_qty_onhand', 'int');
        $user_id = $_SESSION['user_id'];

        $errors = [];
        if (!$item_name || !$item_desc || $item_price < 0 || $item_qty < 0) {
            $errors[] = "All fields must be correctly filled.";
        }

        // --- Handle image upload ---
        $item_image = null;
        if (isset($_FILES['item_image']) && $_FILES['item_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = __DIR__ . '/../public/assets/uploads/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

            $file_tmp = $_FILES['item_image']['tmp_name'];
            $file_name = time() . '_' . basename($_FILES['item_image']['name']);
            $target_path = $upload_dir . $file_name;

            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $file_type = mime_content_type($file_tmp);

            if (in_array($file_type, $allowed_types)) {
                if (move_uploaded_file($file_tmp, $target_path)) {
                    $item_image = '../public/assets/uploads/' . $file_name; // relative path for display
                } else {
                    $errors[] = "Failed to save uploaded image.";
                }
            } else {
                $errors[] = "Invalid image format. Please upload JPG, PNG, GIF, or WEBP.";
            }
        }

        if (empty($errors)) {
            $stmt = $conn->prepare("INSERT INTO inventory (user_id, item_name, item_desc, item_price, item_qty_onhand, item_image)
                                    VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $item_name, $item_desc, $item_price, $item_qty, $item_image]);
            $_SESSION['success_message'] = "Item added successfully!";
        } else {
            $_SESSION['error_message'] = implode("<br>", $errors);
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;

    // --- UPDATE ITEM ---
    } elseif ($form_type === 'update_item' && isset($_SESSION['user_id'])) {
        $item_id = get_post_data('item_id', 'int');
        $item_name = get_post_data('item_name');
        $item_desc = get_post_data('item_desc');
        $item_price = get_post_data('item_price', 'float');
        $item_qty = get_post_data('item_qty_onhand', 'int');
        $user_id = $_SESSION['user_id'];

        $stmt = $conn->prepare("UPDATE inventory 
                                SET item_name=?, item_desc=?, item_price=?, item_qty_onhand=? 
                                WHERE item_id=? AND user_id=?");
        $stmt->execute([$item_name, $item_desc, $item_price, $item_qty, $item_id, $user_id]);
        $_SESSION['success_message'] = "Item updated successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;

    // --- DELETE ITEM ---
    } elseif ($form_type === 'delete_item' && isset($_SESSION['user_id'])) {
        $item_id = get_post_data('item_id', 'int');
        $user_id = $_SESSION['user_id'];

        $stmt = $conn->prepare("DELETE FROM inventory WHERE item_id=? AND user_id=?");
        $stmt->execute([$item_id, $user_id]);
        $_SESSION['success_message'] = "Item deleted.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

// ----------------------------
// Get items for logged-in user
// ----------------------------
$items = [];
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account - Betsy</title>
    <link rel="stylesheet" href="../public/assets/css/styles.css">
    <link rel="stylesheet" href="../public/assets/css/account.css">
    <script>
        window.BASE_URL = '<?= BASE_URL ?>';
        window.ASSETS_PATH = (window.BASE_URL ? window.BASE_URL : '') + '/assets';
    </script>
</head>
<body>
    <?php require_once BASE_PATH.'/src/includes/header.php';?>

<div class="layout">
    <?php if (isset($NAV_HTML)) echo $NAV_HTML; ?>
    <main class="container">
        
        <div class="account-container">
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="message-error"><?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="message-success"><?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
            <?php endif; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <!-- User is signed in: show welcome and sign out button -->
                <div class="form-flex-container">
                    <div class="form-section" style="text-align: center; flex: 1; max-width: 400px;">
                        <h2>Welcome Back!</h2>
                        <p style="font-size: 1.1rem; margin-bottom: 1.5rem;">You are logged in as <strong><?= htmlspecialchars($_SESSION['email'], ENT_QUOTES, 'UTF-8') ?></strong></p>
                        <form method="post" action="./logout.php" style="display:inline; margin-top:0.5rem;">
                            <input type="hidden" name="redirect" value="./account.php">
                            <button type="submit" style="background:#e74c3c; color: #fff; padding: 0.5rem 1rem; border-radius: 4px; text-decoration: none; display: inline-block; border: none;">Sign Out</button>
                        </form>
                    </div>
                </div>

                <hr>
            <?php else: ?>
                <!-- User is not signed in: show sign up and login forms -->
                <div class="form-flex-container">
                    <div class="form-section">
                        <h2>Sign Up</h2>
                        <form action="" method="post" class="account-form">
                            <input type="hidden" name="form_type" value="signup">
                            <input type="text" name="fname" placeholder="First Name" required>
                            <input type="text" name="lname" placeholder="Last Name" required>
                            <input type="email" name="email" placeholder="Email" required>
                            <input type="password" name="password" placeholder="Password" required>
                            <button type="submit">Sign Up</button>
                        </form>
                    </div>

                    <div class="form-section">
                        <h2>Log In</h2>
                        <form action="" method="post" class="account-form">
                            <input type="hidden" name="form_type" value="login">
                            <input type="email" name="email" placeholder="Email" required>
                            <input type="password" name="password" placeholder="Password" required>
                            <button type="submit">Log In</button>
                        </form>
                    </div>
                </div>

                <hr>
            <?php endif; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="items-management">
                    <h2>Item Management</h2>

                    <div class="add-item-section form-section" style="margin-bottom: 2rem;">
                        <h3>➕ Add New Item</h3>
                        <form action="" method="post" class="item-form" enctype="multipart/form-data">
                            <input type="hidden" name="form_type" value="add_item">
                            <input type="text" name="item_name" placeholder="Item Name" required>
                            <input type="text" name="item_desc" placeholder="Item Description" required>
                            <input type="number" name="item_price" placeholder="Item Price" step="0.01" required>
                            <input type="file" name="item_image" accept="image/*">
                            <input type="number" name="item_qty_onhand" placeholder="Quantity On Hand" required>
                            <button type="submit">Add Item</button>
                        </form>
                    </div>

                    <div class="items-list">
                        <h3>Your Inventory</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Image</th>
                                    <th>Qty</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($items)): foreach ($items as $item): ?>
                                    <tr>
                                        <form method="post" style="display:contents;">
                                            <input type="hidden" name="form_type" value="update_item">
                                            <input type="hidden" name="item_id" value="<?= $item['item_id'] ?>">
                                            <td><input type="text" name="item_name" value="<?= esc($item['item_name']) ?>"></td>
                                            <td><input type="text" name="item_desc" value="<?= esc($item['item_desc']) ?>"></td>
                                            <td><input type="number" step="0.01" name="item_price" value="<?= esc($item['item_price']) ?>"></td>
                                            <td style="text-align:center;">
                                                <?php if (!empty($item['item_image'])): ?>
                                                    <img src="<?= esc($item['item_image']) ?>" alt="" width="80" height="80">
                                                <?php else: ?>
                                                    No image
                                                <?php endif; ?>
                                            </td>
                                            <td><input type="number" name="item_qty_onhand" value="<?= esc($item['item_qty_onhand']) ?>"></td>
                                            <td>
                                                <button type="submit">Update</button>
                                        </form>
                                        <form method="post" onsubmit="return confirm('Delete this item?');" style="display:inline;">
                                            <input type="hidden" name="form_type" value="delete_item">
                                            <input type="hidden" name="item_id" value="<?= $item['item_id'] ?>">
                                            <button type="submit">Delete</button>
                                        </form>
                                            </td>
                                    </tr>
                                <?php endforeach; else: ?>
                                    <tr><td colspan="6" style="text-align:center;">No items found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <p style="text-align:center; margin-top:2rem;">Please log in to manage your items.</p>
            <?php endif; ?>
        </div>
    </main>
</div>

<?php require_once BASE_PATH.'/src/includes/footer.php';?>

</body>
</html>
