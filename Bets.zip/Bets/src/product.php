<?php require_once BASE_PATH.'/src/header.php/';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product - Betsy</title>
  <link rel="stylesheet" href="../public/assets/css/styles.css">
  <script defer src="../public/assets/script/script.js"></script>
</head>
<body class="pages-product">
  <header>
    <img src="../public/assets/img/logo.png" alt="Betsy Logo" class="logo">
    <h1>Betsy</h1>
  </header>

  <div class="app">
    <main>
      <section id="product-detail"></section>
      <h3>Similar Products</h3>
      <section id="similar-products" class="product-grid"></section>
    </main>
  </div>
  
<?php require_once BASE_PATH.'/src/footer.php/';?>
</body>
</html>

