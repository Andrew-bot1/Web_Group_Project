<?php require_once __DIR__.'/../config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product - Betsy</title>
  <link rel="stylesheet" href="../public/assets/css/styles.css">
  <script>
    window.BASE_URL = '<?= BASE_URL ?>';
    window.ASSETS_PATH = (window.BASE_URL ? window.BASE_URL : '') + '/assets';
  </script>
  <script defer src="../public/assets/scripts/script.js"></script>
</head>
<body class="pages-product">
  <?php require_once BASE_PATH.'/src/includes/header.php';?>

  <div class="app">
    <?php if (isset($NAV_HTML)) echo $NAV_HTML; ?>
    <main>
      <section id="product-detail"></section>
      <h3>Similar Products</h3>
      <section id="similar-products" class="product-grid"></section>
    </main>
  </div>

  <?php require_once BASE_PATH.'/src/includes/footer.php'; ?>

  <script>
    document.addEventListener('DOMContentLoaded', renderProductPage);
  </script>
</body>
</html>
