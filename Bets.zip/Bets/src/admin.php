<?php
require_once __DIR__.'/../config/config.php';

session_start();

// Admin password
$ADMIN_PASSWORD = 'admin123';

// Database connection
$host = 'localhost';
$db   = 'betsy_db';
$user = 'root';
$pass = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check if user is authenticated
$is_authenticated = isset($_SESSION['admin_authenticated']) && $_SESSION['admin_authenticated'] === true;

// Logout via POST is handled by src/logout.php (centralized)

// Handle password submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_password'])) {
    if ($_POST['admin_password'] === $ADMIN_PASSWORD) {
        $_SESSION['admin_authenticated'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $password_error = "Incorrect password.";
    }
}

// Handle database operations (only if authenticated)
if ($is_authenticated && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['db_action'])) {
    $action = $_POST['db_action'];
    $message = '';

    try {
        if ($action === 'delete_user') {
            $user_id = (int)$_POST['user_id'];
            $stmt = $conn->prepare("DELETE FROM user_table WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $message = "User deleted successfully.";

        } elseif ($action === 'delete_item') {
            $item_id = (int)$_POST['item_id'];
            $stmt = $conn->prepare("DELETE FROM inventory WHERE item_id = ?");
            $stmt->execute([$item_id]);
            $message = "Item deleted successfully.";

        } elseif ($action === 'edit_item') {
            $item_id = (int)$_POST['item_id'];
            $item_name = $_POST['item_name'];
            $item_desc = $_POST['item_desc'];
            $item_price = (float)$_POST['item_price'];
            $item_qty = (int)$_POST['item_qty_onhand'];
            
            $stmt = $conn->prepare("UPDATE inventory SET item_name = ?, item_desc = ?, item_price = ?, item_qty_onhand = ? WHERE item_id = ?");
            $stmt->execute([$item_name, $item_desc, $item_price, $item_qty, $item_id]);
            $message = "Item updated successfully.";

        } elseif ($action === 'add_item') {
            $user_id = (int)$_POST['user_id'];
            $item_name = $_POST['item_name'];
            $item_desc = $_POST['item_desc'];
            $item_price = (float)$_POST['item_price'];
            $item_qty = (int)$_POST['item_qty_onhand'];
            
            $stmt = $conn->prepare("INSERT INTO inventory (user_id, item_name, item_desc, item_price, item_qty_onhand) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $item_name, $item_desc, $item_price, $item_qty]);
            $message = "Item added successfully.";

        } elseif ($action === 'custom_sql') {
            $sql = $_POST['custom_sql'];
            // Only allow SELECT for safety (prevent accidental deletes)
            if (stripos($sql, 'SELECT') !== false) {
                $result = $conn->query($sql);
                $rows = $result->fetchAll(PDO::FETCH_ASSOC);
                $_SESSION['sql_result'] = $rows;
                $message = "Query executed. " . count($rows) . " rows returned.";
            } else {
                $message = "Only SELECT queries are allowed for safety.";
            }
        }
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Fetch all users and items
$users = [];
$items = [];
$sql_result = isset($_SESSION['sql_result']) ? $_SESSION['sql_result'] : [];

if ($is_authenticated) {
    $users = $conn->query("SELECT * FROM user_table")->fetchAll(PDO::FETCH_ASSOC);
    $items = $conn->query("SELECT * FROM inventory")->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Betsy</title>
    <link rel="stylesheet" href="../public/assets/css/styles.css">
    <style>
        .admin-content { max-width: 1200px; margin: 2rem auto; }
        .admin-section { margin: 2rem 0; padding: 1.5rem; background: #f9f9f9; border-radius: 8px; }
        .admin-section h3 { color: #2c3e50; margin-bottom: 1rem; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #34495e; color: #fff; padding: 0.75rem; text-align: left; }
        td { padding: 0.75rem; border-bottom: 1px solid #ddd; }
        tr:hover { background: #f0f0f0; }
        .btn-small { padding: 0.4rem 0.8rem; font-size: 0.85rem; }
        textarea { width: 100%; padding: 0.75rem; font-family: monospace; }
        .login-form { max-width: 400px; margin: 3rem auto; padding: 2rem; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .login-form input { width: 100%; padding: 0.75rem; margin: 0.75rem 0; border: 1px solid #ddd; border-radius: 4px; }
        .login-form button { width: 100%; padding: 0.75rem; background: #3498db; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 1rem; }
        .login-form button:hover { background: #2980b9; }
        .error { color: #e74c3c; }
        .success { color: #27ae60; }
    </style>
    <script>
        window.BASE_URL = '<?= BASE_URL ?>';
        window.ASSETS_PATH = window.BASE_URL + '/assets';
    </script>
</head>
<body>
    <?php $HEADER_PART = 'banner'; require_once BASE_PATH.'/src/includes/header.php';?>

    <div class="layout">
        <?php if (isset($NAV_HTML)) echo $NAV_HTML; ?>
        <main style="flex: 1; padding: 2rem; max-height: calc(100vh - 180px); overflow-y: auto;">

            <?php if (!$is_authenticated): ?>
                <!-- Password Login -->
                <div class="login-form">
                    <h2 style="text-align: center;">Admin Panel</h2>
                    <form method="POST">
                        <label>Admin Password:</label>
                        <input type="password" name="admin_password" placeholder="Enter admin password" required>
                        <button type="submit">Login</button>
                        <?php if (isset($password_error)): ?>
                            <p class="error" style="text-align: center; margin-top: 1rem;"><?= htmlspecialchars($password_error) ?></p>
                        <?php endif; ?>
                    </form>
                </div>

            <?php else: ?>
                <!-- Authenticated Admin Panel -->
                <div class="admin-content">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                        <h2>Admin Panel</h2>
                        <form method="post" action="./logout.php" style="display:inline;">
                            <input type="hidden" name="redirect" value="./admin.php">
                            <button type="submit" style="background: #e74c3c; color: #fff; padding: 0.5rem 1rem; border-radius: 4px; text-decoration: none; border: none; cursor: pointer;">Logout</button>
                        </form>
                    </div>

                    <?php if (isset($message)): ?>
                        <div style="background: #d4edda; color: #155724; padding: 1rem; border-radius: 4px; margin-bottom: 1rem;">
                            <?= htmlspecialchars($message) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Users Management -->
                    <div class="admin-section">
                        <h3>📋 Users Management</h3>
                        <div class="table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($user['user_id']) ?></td>
                                            <td><?= htmlspecialchars($user['first_name']) ?></td>
                                            <td><?= htmlspecialchars($user['last_name']) ?></td>
                                            <td><?= htmlspecialchars($user['email']) ?></td>
                                            <td>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="db_action" value="delete_user">
                                                    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                                                    <button type="submit" class="btn-small" onclick="return confirm('Delete this user?');" style="background: #e74c3c; color: #fff; border: none; border-radius: 4px; cursor: pointer;">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if (empty($users)): ?>
                            <p>No users found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Items Management -->
                    <div class="admin-section">
                        <h3>📦 Items Management</h3>
                        
                        <!-- Add New Item -->
                        <div style="background: #fff; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem;">
                            <h4>Add New Item</h4>
                            <form method="POST">
                                <input type="hidden" name="db_action" value="add_item">
                                <select name="user_id" required style="width: 100%; padding: 0.5rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                                    <option value="">Select User</option>
                                    <?php foreach ($users as $user): ?>
                                        <option value="<?= $user['user_id'] ?>"><?= htmlspecialchars($user['email']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="item_name" placeholder="Item Name" required style="width: 100%; padding: 0.5rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                                <input type="text" name="item_desc" placeholder="Item Description" required style="width: 100%; padding: 0.5rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                                <input type="number" name="item_price" placeholder="Item Price" step="0.01" required style="width: 100%; padding: 0.5rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                                <input type="number" name="item_qty_onhand" placeholder="Quantity" required style="width: 100%; padding: 0.5rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                                <button type="submit" style="background: #3498db; color: #fff; padding: 0.5rem 1rem; border: none; border-radius: 4px; cursor: pointer;">Add Item</button>
                            </form>
                        </div>

                        <!-- Items Table -->
                        <div class="table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Item ID</th>
                                        <th>User ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($items as $item): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($item['item_id']) ?></td>
                                            <td><?= htmlspecialchars($item['user_id']) ?></td>
                                            <td><?= htmlspecialchars($item['item_name']) ?></td>
                                            <td><?= htmlspecialchars($item['item_desc']) ?></td>
                                            <td>$<?= htmlspecialchars($item['item_price']) ?></td>
                                            <td><?= htmlspecialchars($item['item_qty_onhand']) ?></td>
                                            <td>
                                                <button class="btn-small" onclick="editItem(<?= $item['item_id'] ?>, '<?= addslashes($item['item_name']) ?>', '<?= addslashes($item['item_desc']) ?>', <?= $item['item_price'] ?>, <?= $item['item_qty_onhand'] ?>)" style="background: #3498db; color: #fff; border: none; border-radius: 4px; cursor: pointer;">Edit</button>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="db_action" value="delete_item">
                                                    <input type="hidden" name="item_id" value="<?= $item['item_id'] ?>">
                                                    <button type="submit" class="btn-small" onclick="return confirm('Delete this item?');" style="background: #e74c3c; color: #fff; border: none; border-radius: 4px; cursor: pointer;">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if (empty($items)): ?>
                            <p>No items found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Custom SQL Queries -->
                    <div class="admin-section">
                        <h3>🔍 Custom SQL Queries (SELECT only)</h3>
                        <form method="POST">
                            <input type="hidden" name="db_action" value="custom_sql">
                            <label>SQL Query:</label>
                            <textarea name="custom_sql" rows="5" placeholder="Enter SELECT query..." required></textarea>
                            <button type="submit" style="background: #3498db; color: #fff; padding: 0.5rem 1rem; border: none; border-radius: 4px; cursor: pointer; margin-top: 0.75rem;">Execute</button>
                        </form>

                        <?php if (!empty($sql_result)): ?>
                            <h4 style="margin-top: 1.5rem;">Query Results:</h4>
                            <div class="table-wrapper">
                                <table>
                                    <thead>
                                        <tr>
                                            <?php foreach (array_keys($sql_result[0]) as $col): ?>
                                                <th><?= htmlspecialchars($col) ?></th>
                                            <?php endforeach; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($sql_result as $row): ?>
                                            <tr>
                                                <?php foreach ($row as $value): ?>
                                                    <td><?= htmlspecialchars($value) ?></td>
                                                <?php endforeach; ?>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Edit Item Modal Form (hidden by default) -->
                <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center;">
                    <div style="background: #fff; padding: 2rem; border-radius: 8px; max-width: 500px; width: 90%;">
                        <h3>Edit Item</h3>
                        <form method="POST">
                            <input type="hidden" name="db_action" value="edit_item">
                            <input type="hidden" name="item_id" id="editItemId">
                            <input type="text" name="item_name" id="editItemName" placeholder="Item Name" required style="width: 100%; padding: 0.75rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                            <input type="text" name="item_desc" id="editItemDesc" placeholder="Item Description" required style="width: 100%; padding: 0.75rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                            <input type="number" name="item_price" id="editItemPrice" placeholder="Item Price" step="0.01" required style="width: 100%; padding: 0.75rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                            <input type="number" name="item_qty_onhand" id="editItemQty" placeholder="Quantity" required style="width: 100%; padding: 0.75rem; margin-bottom: 0.75rem; border: 1px solid #ddd; border-radius: 4px;">
                            <div style="display: flex; gap: 1rem;">
                                <button type="submit" style="background: #3498db; color: #fff; padding: 0.75rem 1.5rem; border: none; border-radius: 4px; cursor: pointer; flex: 1;">Save</button>
                                <button type="button" onclick="closeEditModal()" style="background: #95a5a6; color: #fff; padding: 0.75rem 1.5rem; border: none; border-radius: 4px; cursor: pointer; flex: 1;">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>

                <script>
                    function editItem(id, name, desc, price, qty) {
                        document.getElementById('editItemId').value = id;
                        document.getElementById('editItemName').value = name;
                        document.getElementById('editItemDesc').value = desc;
                        document.getElementById('editItemPrice').value = price;
                        document.getElementById('editItemQty').value = qty;
                        document.getElementById('editModal').style.display = 'flex';
                    }

                    function closeEditModal() {
                        document.getElementById('editModal').style.display = 'none';
                    }

                    // Close modal when clicking outside
                    document.getElementById('editModal').addEventListener('click', function(e) {
                        if (e.target === this) {
                            this.style.display = 'none';
                        }
                    });
                </script>

            <?php endif; ?>

        </main>
    </div>

    <?php require_once BASE_PATH.'/src/includes/footer.php';?>
</body>
</html>
