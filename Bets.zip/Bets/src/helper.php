<?php
$user_id = $password = $email = $fname = $lname = "";
$errors = [];
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_type = clean('form_type'); // which form was submitted

    if ($form_type === 'signup') {
        $fname = clean('fname');
        $lname = clean('lname');
        $email = clean('email', 'email');
        $password = clean('password');

        if (empty($fname)) $errors[] = "First name is required.";
        if (empty($lname)) $errors[] = "Last name is required.";
        if (empty($email)) $errors[] = "Email is required.";
        if (empty($password)) $errors[] = "Password is required.";
        elseif (!preg_match("/(?=.*\d).{6,}/", $password))
            $errors[] = "Password must be at least 6 characters and include a number.";

        if (empty($errors)) {
            $success = "Registration successful for " . esc($fname) . "!";
            $fname = $lname = $email = $password = "";
        }

    } elseif ($form_type === 'login') {
        $user_id = clean('user_id');
        $password = clean('password');

        if (empty($user_id)) $errors[] = "User ID is required.";
        elseif (!is_numeric($user_id) || $user_id < 0)
            $errors[] = "User ID must be a number that is at least 0.";

        if (empty($password)) $errors[] = "Password is required.";
        elseif (!preg_match("/(?=.*\d).{6,}/", $password))
            $errors[] = "Password must be at least 6 characters and include a number.";

        if (empty($errors)) {
            $success = "Login successful! User ID: " . esc($user_id);
            $user_id = $password = "";
        }
    }
}

function clean($key, $type = 'string', $src = INPUT_POST) {
    $filter = FILTER_SANITIZE_SPECIAL_CHARS;
    $options = 0;
    if ($type === 'email') $filter = FILTER_SANITIZE_EMAIL;
    elseif ($type === 'url') $filter = FILTER_SANITIZE_URL;
    elseif ($type === 'int') $filter = FILTER_SANITIZE_NUMBER_INT;
    elseif ($type === 'float') {
        $filter = FILTER_SANITIZE_NUMBER_FLOAT;
        $options = FILTER_FLAG_ALLOW_FRACTION;
    }
    $value = filter_input($src, $key, $filter, $options);
    return trim($value ?? '');
}

function esc($val) {
    return htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
}
?>
