<?php require_once __DIR__.'/../config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home - Betsy</title>
  <link rel="stylesheet" href="../public/assets/css/styles.css">
  <script>
    // Expose BASE_URL from PHP to client-side scripts so JS can build correct absolute paths
    window.BASE_URL = '<?= BASE_URL ?>';
    window.ASSETS_PATH = (window.BASE_URL ? window.BASE_URL : '') + '/assets';
  </script>
  <script defer src="../public/assets/scripts/script.js"></script>
</head>
<body>
  <?php require_once BASE_PATH.'/src/includes/header.php';?>
  
  <div class="layout">
    <?php if (isset($NAV_HTML)) echo $NAV_HTML; ?>
    <main>
      <h2>Available Products</h2>
      <section id="home-grid" class="product-grid"></section>
    </main>
  </div>
  
  <?php require_once BASE_PATH.'/src/includes/footer.php';?>
</body>
</html>