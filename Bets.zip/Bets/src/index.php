<?php require_once __DIR__.'/../config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home - Betsy</title>
  <link rel="stylesheet" href="../public/assets/css/styles.css">
  <script defer src="../public/assets/scripts/script.js"></script>
</head>
<body>
  <header>
    <img src="../public/assets/images/logo.png" alt="Betsy Logo" class="logo">

    <h1>Betsy</h1>
  </header>

  
<div class="layout">
  <?php require_once BASE_PATH.'/src/includes/header.php';?>
  <main>

      <h2>Available Products</h2>
      
<section id="home-grid" class="product-grid"></section>

    
  </main>
</div>
<?php require_once BASE_PATH.'/src/includes/footer.php';?>
</body>
</html>