<?php require_once BASE_PATH.'/src/header.php/';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home - Betsy</title>
  <link rel="stylesheet" href="../public/assets/css/styles.css">
  <script defer src="../public/assets/script/script.js"></script>
</head>
<body>
<div class="layout">
  <main>

      <h2>Available Products</h2>
      
<section id="home-grid" class="product-grid"></section>

    
  </main>
</div>
</body>
</html>

<?php require_once BASE_PATH.'/src/footer.php/';?>