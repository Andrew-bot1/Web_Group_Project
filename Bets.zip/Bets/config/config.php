<?php

define('BASE_PATH', dirname(__DIR__));
define('BASE_URL', '/Bets/public');
?>