-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql206.infinityfree.com
-- Generation Time: Dec 15, 2025 at 06:15 PM
-- Server version: 11.4.7-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_40641407_db_betsy`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_desc` varchar(200) NOT NULL,
  `item_price` decimal(10,2) NOT NULL,
  `item_image` varchar(255) NOT NULL,
  `item_qty_onhand` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `overlay_shift_x` int(11) DEFAULT 0,
  `overlay_shift_y` int(11) DEFAULT 0,
  `overlay_scale` float DEFAULT 1,
  `overlay_center_in_canvas` tinyint(1) DEFAULT 0,
  `overlay_source` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`item_id`, `item_name`, `item_desc`, `item_price`, `item_image`, `item_qty_onhand`, `user_id`, `overlay_shift_x`, `overlay_shift_y`, `overlay_scale`, `overlay_center_in_canvas`, `overlay_source`) VALUES
(5, 'Recursive Strawberry', 'A picture of a picure of a picture of Betsy holding a strawberry', '1.00', 'public/assets/uploads/combined_edited_1765837135.png', 1, 3, -14, 0, 0.7, 1, NULL),
(6, 'Rock', 'A rock from outside', '21.99', 'public/assets/uploads/combined_1765837256_theRock.png', 1, 5, 0, 0, 1, 0, NULL),
(7, 'Hat', 'A very dapper looking hat.', '78.21', 'public/assets/uploads/combined_1765837468_tophat.png', 50, 5, 0, 0, 1, 0, NULL),
(8, 'Mystery Gift', 'A Christmas gift hand-crafted by the one and only Betsy. The item that is inside is valued at over $1,000.', '10.00', 'public/assets/uploads/combined_1765837810_gift.png', 1, 5, 0, 0, 1, 0, NULL),
(9, 'testing', 'test', '10.50', 'public/assets/uploads/combined_1765838067_image.png', 3, 4, 0, 0, 1, 0, NULL),
(10, 'car', 'car', '80000.00', 'public/assets/uploads/combined_1765838205_car.png', 1, 4, 0, 0, 1, 0, NULL),
(11, 'Cookies', 'A hot tray of chocolate chip cookies.', '3.99', 'public/assets/uploads/combined_1765838377_cookies.png', 100, 5, 0, 0, 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(3, 'Gunner', 'Flory', 'gunner.flory@gmail.com', '$2y$10$ZgHx70FVeoJnTlBMOXb4heh5SB8Ib8SFTIaPO1sXyLsmACORYGKfG'),
(4, 'Test', 'Test', 'test@test.com', '$2y$10$aEttTQk5Z.vYzkf17gK0j.qZAmb1OlW9qqxrmdofwUSJsfl7GG0Zm'),
(5, 'Betsy', 'Betsy', 'betsy@email.com', '$2y$10$t3je3f1NBdCVf.Mmdymb6OPhxK0e127im6r/6SK3y3M/01Q4m/YEK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `user_id_foreignkey` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
