
document.addEventListener('DOMContentLoaded', () => {
  // Canonical product catalog
  let products = JSON.parse(localStorage.getItem('products')) || [
    { id: 1, name: 'Sample Product A', quantity: 5, price: 120, category: 'Electronics', img: 'assets/img/product1.jpg', description: 'A great electronic gadget with useful features.' },
    { id: 2, name: 'Sample Product B', quantity: 3, price: 150, category: 'Electronics', img: 'assets/img/product2.jpg', description: 'Premium electronic device for enthusiasts.' },
    { id: 3, name: 'Sample Product C', quantity: 10, price: 45, category: 'Books', img: 'assets/img/product3.jpg', description: 'A captivating book that keeps you engaged.' },
    { id: 4, name: 'Sample Product D', quantity: 7, price: 80, category: 'Home', img: 'assets/img/product4.jpg', description: 'Useful home item to make life easier.' },
    { id: 5, name: 'Sample Product E', quantity: 12, price: 60, category: 'Books', img: 'assets/img/product5.jpg', description: 'Another great read for your collection.' },
    { id: 6, name: 'Sample Product F', quantity: 2, price: 300, category: 'Electronics', img: 'assets/img/product6.jpg', description: 'High-end electronics for power users.' }
  ];
  localStorage.setItem('products', JSON.stringify(products));
  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  // --- HOME PAGE: Image + name grid ---
  const grid = document.getElementById('product-grid');
  if (grid && document.title.includes('Home')) {
    grid.innerHTML = '';
    products.forEach(p => {
      const card = document.createElement('a');
      card.className = 'product-card';
      card.href = `pages/product.html?id=${p.id}`;
      card.innerHTML = `
        <img src="${p.img}" alt="${p.name}" onerror="this.style.opacity=0.2">
        <div class="product-name">${p.name}</div>
      `;
      grid.appendChild(card);
    });
  }

  
// --- PRODUCT DETAIL PAGE ---
const productDetailEl = document.getElementById('product-detail');
if (productDetailEl) {
  const params = new URLSearchParams(window.location.search);
  const id = parseInt(params.get('id'), 10);
  let pIndex = products.findIndex(x => x.id === id);
  if (pIndex === -1) pIndex = 0;
  let p = products[pIndex];

  function renderDetail() {
    productDetailEl.innerHTML = `
      <div class="product-detail-card">
        <img src="../${p.img}" alt="${p.name}" onerror="this.style.opacity=0.2">
        <div class="info">
          <h2>${p.name}</h2>
          <p class="category">Category: ${p.category}</p>
          <p>${p.description}</p>
          <p class="price">Price: $${p.price}</p>
          <p class="qty ${p.quantity <= 0 ? 'out' : ''}">${p.quantity > 0 ? 'In Stock: ' + p.quantity : 'Out of Stock'}</p>
          <div class="actions">
            <button id="add-to-cart" ${p.quantity <= 0 ? 'disabled' : ''}>${p.quantity > 0 ? 'Add to Cart' : 'Out of Stock'}</button>
          </div>
        </div>
      </div>
    `;

    // Wire up add-to-cart to decrement stock and persist
    const addBtn = document.getElementById('add-to-cart');
    if (addBtn) {
      addBtn.addEventListener('click', () => {
        if (p.quantity <= 0) return;
        // Update cart
        cart.push({ name: p.name, price: p.price });
        localStorage.setItem('cart', JSON.stringify(cart));

        // Decrement stock and persist
        p.quantity = Math.max(0, (p.quantity || 0) - 1);
        products[pIndex] = p;
        localStorage.setItem('products', JSON.stringify(products));

        // Re-render to reflect new stock and button state
        renderDetail();
      });
    }
  }

  renderDetail();

  // Similar products by category
  const similarWrap = document.getElementById('similar-products');
  if (similarWrap) {
    function renderSimilar() {
      const pCurrent = products[pIndex];
      const sim = products.filter(x => x.category === pCurrent.category && x.id !== pCurrent.id);
      similarWrap.innerHTML = '';
      if (sim.length === 0) {
        similarWrap.innerHTML = '<p>No similar products.</p>';
      } else {
        sim.forEach(s => {
          const card = document.createElement('a');
          card.className = 'product-card';
          card.href = `product.html?id=${s.id}`;
          card.innerHTML = `
            <img src="../${s.img}" alt="${s.name}" onerror="this.style.opacity=0.2">
            <div class="product-name">${s.name}</div>
          `;
          similarWrap.appendChild(card);
        });
      }
    }
    renderSimilar();
  }
}
);