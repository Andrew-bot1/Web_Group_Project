<?php
include "helper.php";
/// ----------------------------
// Database connection settings
// ----------------------------
$host = 'localhost';
$db   = 'betsy_db';
$user = 'root';
$pass = '';

session_start();



// ----------------------------
// CONNECT TO DATABASE
// ----------------------------
try {
  $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Connection failed: " . $e->getMessage());
}


// ----------------------------
// ADD (CREATE) AN ITEM
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['insert'])) {

    // Get user input and clean it
    $name = clean('item_name');
    $price = clean('item_price','float');

    // Validation
    $errors = [];
    if (empty($name)) {
        $errors[] = "Name is required.";
    }
    if (!is_numeric($price) || $price < 0) {
        $errors[] = "Price must be a positive number.";
    }

    // If no errors, insert the record
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("INSERT INTO inventory (name, price) VALUES (:name, :price)");
            $stmt->bindParam(':item_name', $name);
            $stmt->bindParam(':price', $price);
            $stmt->execute();
            $_SESSION['success_message'] = "Item added successfully!";
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error adding item.";
        }
    } else {
        // Store validation errors in the session
        $_SESSION['error_message'] = implode("<br>", $errors); //implode joins array elements into a string. Used for display
    }

    // Redirect to avoid duplicate form submissions
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}


// ----------------------------
// UPDATE AN ITEM
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $id = clean('item_id','int');
    $name = clean('name');
    $price = clean('price', 'float');

    $errors = [];
    if (empty($name)) {
        $errors[] = "Name is required.";
    }
    if (!is_numeric($price) || $price < 0) {
        $errors[] = "Price must be a positive number.";
    }

    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("UPDATE inventory SET name = :name, price = :price WHERE item_id = :id");
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':name', $item_name);
            $stmt->bindParam(':price', $price);
            $stmt->execute();
            $_SESSION['success_message'] = "Item updated successfully!";
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error updating item.";
        }
    } else {
        $_SESSION['error_message'] = implode("<br>", $errors);
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}


// ----------------------------
// DELETE AN ITEM
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $id = clean('item_id','int');

    try {
        $stmt = $conn->prepare("DELETE FROM inventory WHERE item_id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $_SESSION['success_message'] = "Item deleted successfully!";
    } catch (PDOException $e) {
        // Handle foreign key constraint errors
        if ($e->getCode() == '23000') {
            $_SESSION['error_message'] = "Cannot delete this item — it’s used in another table.";
        } else {
            $_SESSION['error_message'] = "Error deleting item.";
        }
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}


// ----------------------------
// DISPLAY ALL inventory
// ----------------------------
$stmt = $conn->query("SELECT * FROM inventory");
$inventory = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Item Management</title>
</head>
<body>
    <h2>Item Management</h2>

    <!-- Display error or success messages -->
    <?php 
    if (isset($_SESSION['error_message'])) { 
        echo "<p style='color:red'>" . $_SESSION['error_message'] . "</p>";
        unset($_SESSION['error_message']);
    } 

    if (isset($_SESSION['success_message'])) { 
        echo "<p style='color:green'>" . $_SESSION['success_message'] . "</p>";
        unset($_SESSION['success_message']); 
    } 
    ?>

    <!-- ADD NEW ITEM FORM -->
    <form method="post">
        <label>Name:</label>
        <input type="text" name="item_name" required>

        <label>Description:</label>
        <input type="text" name="item_desc" required>

        <label>Price:</label>
        <input type="number" step="0.01" name="item_price" required>

        <label>Image:</label>
        <input type="file"  name="item_image" required>

        <label>Quantity:</label>
        <input type="number" name="item_qty_onhand" required>

        <button type="submit" name="insert">Add Item</button>
    </form>

    <h3>Items List</h3>
    <table border="1" cellpadding="5">
        <tr><th>Name</th><th>Price</th><th>Action</th></tr>
        <?php foreach ($inventory as $item): ?>
            <tr>
                <td><?= esc($item['item_name']) ?></td>
                <td><?= esc($item['Item_price']) ?></td>
                <td>
                    <!-- UPDATE/DELETE FORM for each row -->
                    <form method="POST">
                        <input type="hidden" name="item_id" value="<?= esc($item['item_id']) ?>">
                        <input type="text" name="item_name" value="<?= esc($item['item_name']) ?>">
                        <input type="text" name="item_desc" value="<?= esc($item['item_desc']) ?>">
                        <input type="number" step="0.01" name="price" value="<?= esc($item['item_price']) ?>">
                        <button type="submit" name="update">Update</button>
                        <button type="submit" name="delete">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
