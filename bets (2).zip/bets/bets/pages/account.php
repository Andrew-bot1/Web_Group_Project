<?php
include 'helper.php';
// ----------------------------
// Database connection settings
// ----------------------------
$host = 'localhost';
$db   = 'betsy_db';
$user = 'root';
$pass = '';

session_start();

// ----------------------------
// CONNECT TO DATABASE
// ----------------------------
try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// ----------------------------
// Initialize variables (for Login/Signup forms)
// ----------------------------
$fname = $lname = $email = $password = "";


// Helper function to clean and get POST data safely
function get_post_data($key, $type = 'string') {
    if (!isset($_POST[$key])) return null;
    $value = $_POST[$key];
    
    // Basic cleaning, assuming 'esc' is your external helper function
    $value = trim($value); 

    if ($type === 'int') {
        return (int) filter_var($value, FILTER_SANITIZE_NUMBER_INT);
    }
    if ($type === 'float') {
        // Replace comma with dot if needed, then filter
        $value = str_replace(',', '.', $value);
        return (float) filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    }
    // Default string cleaning
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}


// ----------------------------
// Handle POST forms
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_type = $_POST['form_type'] ?? '';

    // --- Sign Up Logic ---
    if ($form_type === 'signup') {
        $fname = $_POST['fname'] ?? '';
        $lname = $_POST['lname'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if (!$fname || !$lname || !$email || !$password) {
            $_SESSION['error_message'] = "All fields are required for sign up.";
        } else {
            // NOTE: In a real application, you must HASH the password here.
            $stmt = $conn->prepare("INSERT INTO user_table (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$fname, $lname, $email, $password]);
            $_SESSION['success_message'] = "Sign up successful! You can now log in.";
            $fname = $lname = $password = ""; 
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;

    // --- Log In Logic ---
    } elseif ($form_type === 'login') {
        $login_email = $_POST['email'] ?? '';
        $login_password = $_POST['password'] ?? '';

        if (!$login_email || !$login_password) {
            $_SESSION['error_message'] = "Email and password are required.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM user_table WHERE email = ? AND password = ?");
            $stmt->execute([$login_email, $login_password]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['success_message'] = "Login successful!";
            } else {
                $_SESSION['error_message'] = "Invalid email or password.";
            }
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    
    // --- ADD (CREATE) AN ITEM ---
    } elseif ($form_type === 'add_item' && isset($_SESSION['user_id'])) {
        $item_name = get_post_data('item_name');
        $item_desc = get_post_data('item_desc');
        $item_price = get_post_data('item_price', 'float');
        $item_qty = get_post_data('item_qty_onhand', 'int');
        $user_id = $_SESSION['user_id'];
        
        $errors = [];
        if (!$item_name || !$item_desc || !is_numeric($item_price) || $item_price < 0 || !is_numeric($item_qty) || $item_qty < 0) {
            $errors[] = "All item fields must be correctly filled.";
        }
        
        if (empty($errors)) {
            try {
                $stmt = $conn->prepare("INSERT INTO inventory (user_id, item_name, item_desc, item_price, item_qty_onhand) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $item_name, $item_desc, $item_price, $item_qty]);
                $_SESSION['success_message'] = "Item added successfully!";
            } catch (PDOException $e) {
                $_SESSION['error_message'] = "Error adding item: " . $e->getMessage();
            }
        } else {
            $_SESSION['error_message'] = implode("<br>", $errors);
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;

    // --- UPDATE AN ITEM ---
    } elseif ($form_type === 'update_item' && isset($_SESSION['user_id'])) {
        $item_id = get_post_data('item_id', 'int');
        $item_name = get_post_data('item_name');
        $item_desc = get_post_data('item_desc');
        $item_price = get_post_data('item_price', 'float');
        $item_qty = get_post_data('item_qty_onhand', 'int');
        $user_id = $_SESSION['user_id'];

        $errors = [];
        if (!$item_name || !$item_desc || !is_numeric($item_price) || $item_price < 0 || !is_numeric($item_qty) || $item_qty < 0) {
            $errors[] = "All item fields must be correctly filled for update.";
        }
        
        if ($item_id <= 0) {
             $errors[] = "Invalid item ID.";
        }

        if (empty($errors)) {
            try {
                $stmt = $conn->prepare("UPDATE inventory SET item_name = ?, item_desc = ?, item_price = ?, item_qty_onhand = ? WHERE item_id = ? AND user_id = ?");
                $stmt->execute([$item_name, $item_desc, $item_price, $item_qty, $item_id, $user_id]);
                
                if ($stmt->rowCount() > 0) {
                    $_SESSION['success_message'] = "Item updated successfully!";
                } else {
                    $_SESSION['error_message'] = "Item not found or no changes were made.";
                }
            } catch (PDOException $e) {
                $_SESSION['error_message'] = "Error updating item: " . $e->getMessage();
            }
        } else {
            $_SESSION['error_message'] = implode("<br>", $errors);
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;

    // --- DELETE AN ITEM ---
    } elseif ($form_type === 'delete_item' && isset($_SESSION['user_id'])) {
        $item_id = get_post_data('item_id', 'int');
        $user_id = $_SESSION['user_id'];

        if ($item_id > 0) {
            try {
                $stmt = $conn->prepare("DELETE FROM inventory WHERE item_id = ? AND user_id = ?");
                $stmt->execute([$item_id, $user_id]);

                if ($stmt->rowCount() > 0) {
                    $_SESSION['success_message'] = "Item successfully deleted.";
                } else {
                    $_SESSION['error_message'] = "Item not found or you don't have permission to delete it.";
                }
            } catch (PDOException $e) {
                if ($e->getCode() == '23000') {
                    $_SESSION['error_message'] = "Cannot delete this item — it might be linked elsewhere.";
                } else {
                    $_SESSION['error_message'] = "Error deleting item: " . $e->getMessage();
                }
            }
        } else {
            $_SESSION['error_message'] = "Invalid item ID for deletion.";
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}


// ----------------------------
// Get items for logged-in user
// ----------------------------
$items = [];
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account - Betsy</title>
<link rel="stylesheet" href="../assets/css/account.css">
</head>
<body>
<header>
    <img src="../assets/img/logo.png" alt="Betsy Logo" class="logo">
    <h1>Betsy</h1>
</header>

<div class="layout">
    <nav>
        <ul>
            <li><a href="../index.html">Home</a></li>
            <li><a href="../pages/upload.html">Upload</a></li>
            <li><a href="../pages/account.php">Account</a></li>
            <li><a href="../pages/contact.html">Contact</a></li>
        </ul>
    </nav>

    <main class="container">
        <div class="account-container">

            <?php 
            if (isset($_SESSION['error_message'])): ?>
                <div class="message-error">
                    <?= $_SESSION['error_message'] ?>
                </div>
            <?php unset($_SESSION['error_message']); 
            endif; ?>

            <?php 
            if (isset($_SESSION['success_message'])): ?>
                <div class="message-success">
                    <?= $_SESSION['success_message'] ?>
                </div>
            <?php unset($_SESSION['success_message']); 
            endif; ?>

            <div class="form-flex-container">
                <div class="form-section">
                    <h2>Sign Up</h2>
                    <form action="" method="post" class="account-form">
                        <input type="hidden" name="form_type" value="signup">
                        <input type="text" name="fname" placeholder="First Name" value="<?= esc($fname) ?>" required>
                        <input type="text" name="lname" placeholder="Last Name" value="<?= esc($lname) ?>" required>
                        <input type="email" name="email" placeholder="Email" value="<?= esc($email) ?>" required>
                        <input type="password" name="password" placeholder="Password" required>
                        <button type="submit">Sign Up</button>
                    </form>
                </div>

                <div class="form-section">
                    <h2>Log In</h2>
                    <form action="" method="post" class="account-form">
                        <input type="hidden" name="form_type" value="login">
                        <input type="email" name="email" placeholder="Email" value="<?= esc($email) ?>" required>
                        <input type="password" name="password" placeholder="Password" required>
                        <button type="submit">Log In</button>
                    </form>
                </div>
            </div>

            <hr>

            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="items-management">
                    <h2>Item Management</h2>

                    <div class="add-item-section form-section" style="margin-bottom: 2rem;">
                        <h3>➕ Add New Item</h3>
                        <form action="" method="post" class="item-form">
                            <input type="hidden" name="form_type" value="add_item">
                            <input type="text" name="item_name" placeholder="Item Name" required>
                            <input type="text" name="item_desc" placeholder="Item Description" required>
                            <input type="number" name="item_price" placeholder="Item Price (e.g., 19.99)" step="0.01" required>
                            <input type="number" name="item_qty_onhand" placeholder="Quantity On Hand" required>
                            <button type="submit">Add Item</button>
                        </form>
                    </div>
                    
                    <div class="items-list">
                        <h3>Your Inventory</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th style="display:none;">User ID</th>
                                    <th style="display:none;">Item ID</th> 
                                    <th style="width: 15%;">Name</th>
                                    <th style="width: 25%;">Description</th>
                                    <th style="width: 10%;">Price</th>
                                    <th style="width: 10%;">Image</th> 
                                    <th style="width: 10%;">Qty</th>
                                    <th style="width: 20%;">Actions</th> 
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($items)): ?>
                                    <?php foreach ($items as $item): ?>
                                        <tr>
                                            <td style="display:none;"><?= $item['user_id'] ?></td>
                                            <td style="display:none;"><?= $item['item_id'] ?></td> 
                                            
                                            <form method="post" style="display:contents;">
                                                <input type="hidden" name="form_type" value="update_item">
                                                <input type="hidden" name="item_id" value="<?= esc($item['item_id']) ?>">
                                                
                                                <td><input type="text" name="item_name" value="<?= esc($item['item_name']) ?>" required></td>
                                                <td><input type="text" name="item_desc" value="<?= esc($item['item_desc']) ?>" required></td>
                                                <td><input type="number" step="0.01" name="item_price" value="<?= esc($item['item_price']) ?>" required></td>
                                                
                                                <td style="text-align: center;">
                                                    <?php if (!empty($item['item_image'])): ?>
                                                        <img src="<?= esc($item['item_image']) ?>" alt="<?= esc($item['item_name']) ?> image" width="80" height="80">
                                                    <?php else: ?>
                                                        No image
                                                    <?php endif; ?>
                                                </td>
                                                
                                                <td><input type="number" name="item_qty_onhand" value="<?= esc($item['item_qty_onhand']) ?>" required></td>
                                                
                                                <td>
                                                    <button type="submit" class="action-button update-button">Update</button>
                                            </form>

                                                <form method="post" class="delete-form" onsubmit="return confirm('Are you sure you want to delete item: <?= esc($item['item_name']) ?>?');">
                                                    <input type="hidden" name="form_type" value="delete_item">
                                                    <input type="hidden" name="item_id" value="<?= $item['item_id'] ?>">
                                                    <button type="submit" class="action-button delete-button">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="8" style="text-align:center;">No items found.</td></tr> 
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <p style="text-align: center; margin-top: 2rem;">Please log in to manage your inventory items.</p>
            <?php endif; ?>

        </div>
    </main>
</div>

<footer>
    <p>&copy; 2025 Betsy</p>
</footer>
</body>
</html>