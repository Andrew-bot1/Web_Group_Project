<?php
function clean($key, $type = 'string', $src = INPUT_POST) {
    $filter = FILTER_SANITIZE_SPECIAL_CHARS;
    $options = 0;
    if ($type === 'email') {
        $filter = FILTER_SANITIZE_EMAIL;
    } elseif ($type === 'url') {
        $filter = FILTER_SANITIZE_URL;
    } elseif ($type === 'int') {
        $filter = FILTER_SANITIZE_NUMBER_INT;
    } elseif ($type === 'float') {
        $filter = FILTER_SANITIZE_NUMBER_FLOAT;
        $options = FILTER_FLAG_ALLOW_FRACTION;
    }

    $value = filter_input($src, $key, $filter, $options);
    return trim($value ?? '');
}

function esc($val) {
    return htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
}

$user_id = $password = $email = $fname = $lname = "";
$errors = [];
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_type = clean('form_type'); // which form was submitted

    if ($form_type === 'signup') {
        $fname = clean('fname');
        $lname = clean('lname');
        $email = clean('email', 'email');
        $password = clean('password');

        if (empty($fname)) {
            $errors[] = "First name is required.";
        }
        if (empty($lname)) {
            $errors[] = "Last name is required.";
        }
        if (empty($email)) {
            $errors[] = "Email is required.";
        }
        if (empty($password)) {
            $errors[] = "Password is required.";
        } elseif (!preg_match("/(?=.*\d).{6,}/", $password)) {
            $errors[] = "Password must be at least 6 characters and include a number.";
        }

        if (empty($errors)) {
            $success = "Registration successful for " . esc($fname) . "!";
            $fname = $lname = $email = $password = "";
        }

    } elseif ($form_type === 'login') {
        $user_id = clean('user_id');
        $password = clean('password');

        if (empty($user_id)) {
            $errors[] = "User ID is required.";
        } elseif (!is_numeric($user_id) || $user_id < 0) {
            $errors[] = "User ID must be a number that is at least 0.";
        }

        if (empty($password)) {
            $errors[] = "Password is required.";
        } elseif (!preg_match("/(?=.*\d).{6,}/", $password)) {
            $errors[] = "Password must be at least 6 characters and include a number.";
        }

        if (empty($errors)) {
            $success = "Login successful! User ID: " . esc($user_id);
            $user_id = $password = "";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Account - Betsy</title>
  <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
  <header>
    <img src="../assets/img/logo.png" alt="Betsy Logo" class="logo">
    <h1>Betsy</h1>
  </header>

  <div class="layout">
    <nav>
      <ul>
        <li><a href="../index.html">Home</a></li>
        <li><a href="../pages/upload.html">Upload</a></li>
        <li><a href="../pages/account.html">Account</a></li>
        <li><a href="../pages/contact.html">Contact</a></li>
      </ul>
    </nav>

    <main class="container">
      <div class="account-container">

        <?php if (!empty($errors)): ?>
          <div class="errors" style="color: red;">
            <ul>
              <?php foreach ($errors as $error): ?>
                <li><?= esc($error) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php elseif (!empty($success)): ?>
          <div class="success" style="color: green;">
            <?= esc($success) ?>
          </div>
        <?php endif; ?>

        <div class="form-section">
          <h2>Sign Up</h2>
          <form action="" method="post">
            <input type="hidden" name="form_type" value="signup">
            First Name: <input type="text" name="fname" value="<?= esc($fname) ?>" ><br><br>
            Last Name: <input type="text" name="lname" value="<?= esc($lname) ?>" ><br><br>
            Password: <input type="password" name="password"
            pattern="(?=.*\d).{6,}"
            title="Minimum 6 characters and at least one number"  ><br><br>
            Email: <input type="email" name="email" value="<?= esc($email) ?>" ><br><br>
            <input type="submit" value="Sign Up">
          </form>
        </div>

        <div class="form-section">
          <h2>Log In</h2>
          <form action="" method="post">
            <input type="hidden" name="form_type" value="login">
            User ID: <input type="text" name="user_id" value="<?= esc($user_id) ?>" required><br><br>
            Password: <input type="password" name="password"
            pattern="(?=.*\d).{6,}"
            title="Minimum 6 characters and at least one number" required ><br><br>
            <input type="submit" value="Log In">
          </form>
        </div>

      </div>
    </main>
  </div>

  <footer>
    <p>&copy; 2025 Betsy</p>
  </footer>
</body>
</html>
