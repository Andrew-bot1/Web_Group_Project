<?php
include 'helper.php';

// ----------------------------
// Database connection
// ----------------------------
$host = 'localhost';
$db   = 'betsy_db';
$user = 'root';
$pass = '';

session_start();

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// ----------------------------
// Initialize variables
// ----------------------------
$fname = $lname = $email = $password = "";
$errors = [];
$success = "";

// ----------------------------
// Handle POST forms
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_type = $_POST['form_type'] ?? '';

    if ($form_type === 'signup') {
        $fname = $_POST['fname'] ?? '';
        $lname = $_POST['lname'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if (!$fname || !$lname || !$email || !$password) {
            $errors[] = "All fields are required for sign up.";
        } else {
            // Insert user
            $stmt = $conn->prepare("INSERT INTO user_table (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$fname, $lname, $email, $password]);
            $success = "Sign up successful! You can now log in.";
            // Clear fields after success for cleaner look, except email for potential login
            $fname = $lname = $password = ""; 
        }
    } elseif ($form_type === 'login') {
        // Only get email and password for login
        $login_email = $_POST['email'] ?? '';
        $login_password = $_POST['password'] ?? '';

        if (!$login_email || !$login_password) {
            $errors[] = "Email and password are required.";
            // Retain the email in the form
            $email = $login_email; 
        } else {
            $stmt = $conn->prepare("SELECT * FROM user_table WHERE email = ? AND password = ?");
            $stmt->execute([$login_email, $login_password]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['email'] = $user['email'];
                $success = "Login successful!";
                // Clear all fields on successful login
                $fname = $lname = $email = $password = ""; 
            } else {
                $errors[] = "Invalid email or password.";
                // Retain the email in the form
                $email = $login_email;
            }
        }
    }
}

// ----------------------------
// Get items for logged-in user
// ----------------------------
$items = [];
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account - Betsy</title>
<link rel="stylesheet" href="../assets/css/styles.css">
<style>
    /* Basic styling for the side-by-side layout and forms */
    .form-flex-container {
        display: flex;
        gap: 2rem;
        flex-wrap: wrap; /* Allows forms to stack on smaller screens */
        justify-content: center;
        margin-bottom: 2rem; /* Separates forms from the items list */
    }

    .form-section {
        flex: 1; 
        min-width: 300px; /* Ensures readability on forms */
        padding: 1.5rem;
        border: 1px solid #ccc; /* Optional visual separation */
        border-radius: 8px;
    }

    .account-form input[type="text"],
    .account-form input[type="email"],
    .account-form input[type="password"] {
        width: 100%;
        padding: 0.5rem;
        margin-bottom: 1rem;
        box-sizing: border-box;
    }

    .items-list {
        width: 100%; /* Ensure table takes full width below forms */
        margin-top: 2rem;
    }

    .items-list table {
        width: 100%;
        border-collapse: collapse;
    }

    .items-list th, .items-list td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
        /* Add max-width for description to prevent table blowout */
        max-width: 200px; 
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .items-list th {
        background-color: #f2f2f2;
    }

    .account-container {
        max-width: 1000px; /* Optional: Limit width of account content */
        margin: 0 auto;
    }
</style>
</head>
<body>
<header>
    <img src="../assets/img/logo.png" alt="Betsy Logo" class="logo">
    <h1>Betsy</h1>
</header>

<div class="layout">
    <nav>
        <ul>
            <li><a href="../index.html">Home</a></li>
            <li><a href="../pages/upload.html">Upload</a></li>
            <li><a href="../pages/account.php">Account</a></li>
            <li><a href="../pages/contact.html">Contact</a></li>
        </ul>
    </nav>

    <main class="container">
        <div class="account-container">

            <?php if (!empty($errors)): ?>
                <div class="message" style="color:red; border: 1px solid red; padding: 10px; margin-bottom: 1rem; border-radius: 5px;">
                    <?php foreach ($errors as $error) echo "<p style='margin: 0;'>&bull; $error</p>"; ?>
                </div>
            <?php elseif (!empty($success)): ?>
                <div class="message" style="color:green; border: 1px solid green; padding: 10px; margin-bottom: 1rem; border-radius: 5px;">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <div class="form-flex-container">
                
                <div class="form-section">
                    <h2>Sign Up</h2>
                    <form action="" method="post" class="account-form">
                        <input type="hidden" name="form_type" value="signup">
                        <input type="text" name="fname" placeholder="First Name" value="<?= esc($fname) ?>" required>
                        <input type="text" name="lname" placeholder="Last Name" value="<?= esc($lname) ?>" required>
                        <input type="email" name="email" placeholder="Email" value="<?= esc($email) ?>" required>
                        <input type="password" name="password" placeholder="Password" required>
                        <button type="submit">Sign Up</button>
                    </form>
                </div>

                <div class="form-section">
                    <h2>Log In</h2>
                    <form action="" method="post" class="account-form">
                        <input type="hidden" name="form_type" value="login">
                        <input type="email" name="email" placeholder="Email" value="<?= esc($email) ?>" required>
                        <input type="password" name="password" placeholder="Password" required>
                        <button type="submit">Log In</button>
                    </form>
                </div>

            </div>

            <hr>
            
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="items-list">
                    <h2>Your Items</h2>
                    <table>
                        <thead>
                            <tr>
                                <th style="display:none;">User ID</th>
                                <th style="display:none;">Item ID</th> 
                                <th>Item Name</th>
                                <th>Item Description</th> <th>Item Price</th>
                                <th>Item Image</th> 
                                <th>Item Qty On Hand</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($items)): ?>
                                <?php foreach ($items as $item): ?>
                                    <tr>
                                        <td style="display:none;"><?= $item['user_id'] ?></td>
                                        <td style="display:none;"><?= $item['item_id'] ?></td> 
                                        <td><?= esc($item['item_name']) ?></td>
                                        <td><?= esc($item['item_desc']) ?></td> <td>$<?= number_format((float)$item['item_price'], 2) ?></td>
                                        <td>
                                            <?php if (!empty($item['item_image'])): ?>
                                                <img src="<?= esc($item['item_image']) ?>" alt="<?= esc($item['item_name']) ?> image" width="80" height="80">
                                            <?php else: ?>
                                                No image
                                            <?php endif; ?>
                                        </td>
                                        <td><?= esc($item['item_qty_onhand']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align:center;">No items found.</td></tr> 
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p style="text-align: center; margin-top: 2rem;">Please log in to view your inventory items.</p>
            <?php endif; ?>

        </div>
    </main>
</div>

<footer>
    <p>&copy; 2025 Betsy</p>
</footer>
</body>
</html>